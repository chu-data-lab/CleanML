alpha:
Plots are generated based on R1.

metric:
Plots are generated based on R3.
clean acc or f1 vs. dirty acc or f1 for 20 splits.
Imbalanced datasets use f1. Others use acc.
Different color => different datasets
Different marker => scenario BD or CD
